import React, { useState } from 'react';
import './LoginOverlay.css';
import nokiaLogo from '../assets/images/Nokia-Logo.png';

const LoginOverlay = ({ onLoginSuccess }) => {
  const [showSignup, setShowSignup] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [signupError, setSignupError] = useState('');
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [showForgot, setShowForgot] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpInput, setOtpInput] = useState('');

  // Demo: store credentials in local state (replace with real backend in production)
  const [credentials, setCredentials] = useState(() => {
    const stored = localStorage.getItem('nokia-credentials');
    return stored ? JSON.parse(stored) : null;
  });

  const handleSignup = (e) => {
    e.preventDefault();
    const username = e.target['signup-username'].value.trim();
    const password = e.target['signup-password'].value;
    setSignupError('');
    if (!username.endsWith('@nokia.com')) {
      setSignupError('Username must end with @nokia.com');
      return;
    }
    if (!/[^A-Za-z0-9]/.test(password)) {
      setSignupError('Password must contain at least one special character.');
      return;
    }
    localStorage.setItem('nokia-credentials', JSON.stringify({ username, password }));
    setCredentials({ username, password });
    setSignupError('Sign up successful! Please login.');
    setTimeout(() => setShowSignup(false), 1200);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const username = e.target['username'].value.trim();
    const password = e.target['password'].value;
    setLoginError('');
    if (!credentials || username !== credentials.username) {
      setLoginError('Invalid user. Please sign up first.');
      return;
    }
    if (!username.endsWith('@nokia.com')) {
      setLoginError('Invalid username or password.');
      setLoginAttempts(a => a + 1);
    } else if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
      setLoginError('Enter at least one special character.');
      setLoginAttempts(a => a + 1);
    } else if (password !== credentials.password) {
      setLoginError('Invalid username or password.');
      setLoginAttempts(a => a + 1);
    } else {
      setLoginError('');
      onLoginSuccess();
      return;
    }
    if (loginAttempts + 1 >= 3) {
      setShowForgot(true);
    }
  };

  const handleSendOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setOtpCode(code);
    setOtpSent(true);
  };

  const handleVerifyOtp = () => {
    if (otpInput === otpCode) {
      setLoginError('');
      onLoginSuccess();
    } else {
      setLoginError('Invalid OTP. Please try again.');
    }
  };

  return (
    <div id="login-overlay" className="login-overlay">
      <img src={nokiaLogo} alt="Nokia Logo" className="login-nokia-logo" />
      <div className="login-overlay-center">
        <div className="login-main-title">ESD DASHBOARD</div>
        <div className="login-box-outline">
          {showSignup ? (
            <form id="signup-form" onSubmit={handleSignup}>
              <h2 className="login-title">Sign Up</h2>
              <div className="login-group">
                <label htmlFor="signup-username">Username</label>
                <input type="text" id="signup-username" name="signup-username" required autoComplete="username" />
              </div>
              <div className="login-group">
                <label htmlFor="signup-password">Password</label>
                <input type="password" id="signup-password" name="signup-password" required autoComplete="new-password" />
              </div>
              <div className="login-error">{signupError}</div>
              <div className="signup-btn-center">
                <button type="submit" className="login-btn" id="signup-btn">Sign Up</button>
              </div>
              <div className="form-switch-prompt"><a href="#" onClick={e => {e.preventDefault(); setShowSignup(false);}}>&larr; Back to Login</a></div>
            </form>
          ) : (
            <form id="login-form" onSubmit={handleLogin}>
              <h2 className="login-title">Login</h2>
              <div className="login-group">
                <label htmlFor="username">Username</label>
                <input type="text" id="username" name="username" required autoComplete="username" />
              </div>
              <div className="login-group">
                <label htmlFor="password">Password</label>
                <input type="password" id="password" name="password" required autoComplete="current-password" />
              </div>
              <div className="login-error">{loginError}</div>
              <div className="signup-btn-center">
                <button type="submit" className="login-btn" id="login-btn" disabled={loginAttempts >= 3 && !showForgot}>Login</button>
              </div>
              <div className="signup-separator"><span>or</span></div>
              <div className="form-switch-prompt">Don't have an account? <a href="#" onClick={e => {e.preventDefault(); setShowSignup(true);}}>Sign Up</a></div>
              {showForgot && (
                <div className="forgot-link">
                  <a href="#" onClick={e => {e.preventDefault(); setOtpSent(false); setOtpInput('');}}>Forgot Password?</a>
                </div>
              )}
              {showForgot && (
                <div className="otp-section">
                  {!otpSent ? (
                    <button type="button" className="login-btn" onClick={handleSendOtp}>Send OTP</button>
                  ) : (
                    <>
                      <div className="login-group">
                        <label htmlFor="otp-input">Enter OTP</label>
                        <input type="text" id="otp-input" maxLength={6} value={otpInput} onChange={e => setOtpInput(e.target.value)} autoComplete="one-time-code" />
                      </div>
                      <button type="button" className="login-btn" onClick={handleVerifyOtp}>Verify OTP</button>
                      <div className="login-error">{otpSent && `OTP sent: ${otpCode}`}</div>
                    </>
                  )}
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginOverlay; 