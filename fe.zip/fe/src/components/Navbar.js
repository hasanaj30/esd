import React from 'react';
import './Navbar.css';
import nokialogo from '../assets/images/Nokia-Logo.png';

const Navbar = () => (
  <nav className="navbar">
    <div className="nav-logo">
      <img src={nokialogo} alt="Nokia Logo" className="logo" />
      <div className="nav-title">ESD DASHBOARD</div>
    </div>
    <div className="nav-actions">
    </div>
  </nav>
);

export default Navbar; 