import React, { useEffect, useState } from 'react';
import './Dashboard.css';

function useTableStatus() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const ws = new window.WebSocket('ws://127.0.0.1:6789');
    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        setData(message);
      } catch (err) {
        console.error('Invalid WebSocket message:', event.data);
      }
    };
    ws.onerror = (err) => {
      console.error('WebSocket error:', err);
    };
    return () => ws.close();
  }, []);

  return data;
}

const TableStatus = () => {
  const data = useTableStatus();

  if (!data) return <div>Loading...</div>;

  return (
    <div>
      <h2>Rework Table 1</h2>
      <p>IR: {data.ir ? 'ON' : 'OFF'}</p>
      <p>Touch: {data.touch ? 'ON' : 'OFF'}</p>
      <p>Ground: {data.ground ? 'ON' : 'OFF'}</p>
    </div>
  );
};

export default TableStatus; 